module.exports.function = function findIBA (Drink) {
  return Drink
}
